# R-Service Tracker

A comprehensive Android application designed to help drivers track their daily work, earnings, and payment schedules. The app allows you to record each day you drive, automatically calculates your earnings at ₹25 per day, and notifies you when it's time to collect your payment every 4 working days.

## Features

✨ **Core Features:**
- 📱 **Daily Work Tracking** - One-click marking for daily work completion
- 💰 **Automatic Earnings Calculation** - ₹25 per day with automatic totaling
- 🔔 **Payment Notifications** - Alerts every 4 working days (₹100)
- 📊 **Comprehensive History** - Weekly and monthly work views
- 📄 **Balance Sheet with Export** - CSV export functionality
- 📈 **Charts and Analytics** - Visual representation of earnings
- 🌙 **Dark/Light Theme Toggle** - Customizable appearance
- 🔥 **Daily Strike Counter** - Track consecutive working days

## Screenshots

*Screenshots will be added once the app is built and tested*

## Technical Stack

- **Language**: Kotlin
- **Architecture**: MVVM (Model-View-ViewModel)
- **Database**: Room (SQLite)
- **UI Framework**: Material Design 3
- **Navigation**: Navigation Drawer
- **Charts**: MPAndroidChart
- **PDF Export**: Custom CSV export
- **Notifications**: Android WorkManager

## Project Structure

```
app/
├── src/main/java/com/rservice/tracker/
│   ├── data/                    # Database entities, DAOs, and converters
│   │   ├── AppDatabase.kt
│   │   ├── WorkEntry.kt
│   │   ├── PaymentBatch.kt
│   │   ├── WorkEntryDao.kt
│   │   ├── PaymentBatchDao.kt
│   │   └── Converters.kt
│   ├── viewmodel/               # ViewModels for business logic
│   │   ├── MainViewModel.kt
│   │   └── MainViewModelFactory.kt
│   ├── adapter/                 # RecyclerView adapters
│   │   └── WorkEntryAdapter.kt
│   ├── MainActivity.kt          # Main dashboard activity
│   ├── HistoryActivity.kt       # Work history with filters
│   ├── BalanceSheetActivity.kt  # Financial summary and export
│   ├── ChartsActivity.kt        # Analytics and charts
│   └── AboutActivity.kt         # App information
└── src/main/res/
    ├── layout/                  # XML layouts
    ├── values/                  # Colors, strings, themes
    ├── drawable/                # Icons and graphics
    └── menu/                    # Navigation menu
```

## Installation & Setup

### Prerequisites
- Android Studio Arctic Fox or later
- Android SDK 24+ (Android 7.0)
- Kotlin 1.9.10+

### Building the Project

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/r-service-tracker.git
   cd r-service-tracker
   ```

2. **Open in Android Studio**
   - Launch Android Studio
   - Select "Open an existing Android Studio project"
   - Navigate to the cloned directory and select it

3. **Sync and Build**
   - Wait for Gradle sync to complete
   - Click "Build" → "Make Project" or press `Ctrl+F9`

4. **Run the App**
   - Connect an Android device or start an emulator
   - Click the "Run" button or press `Shift+F10`

## Usage Guide

### Getting Started
1. **Launch the App** - Open R-Service Tracker on your device
2. **Mark Daily Work** - Tap "Mark Work Done" button each day you drive
3. **Track Progress** - View your daily strike counter and earnings summary
4. **Payment Notifications** - Receive alerts when ₹100 is ready for collection

### Key Screens

#### 📱 Dashboard
- Current date and work status
- Daily strike counter showing consecutive working days
- Earnings summary (total earned vs. unpaid)
- Payment status indicator
- Quick access to history and balance sheet

#### 📋 History
- Filter by All, This Week, Last Week, This Month, Last Month
- Detailed work entries with dates and payment status
- Summary statistics (total days, paid days, unpaid days)

#### 💰 Balance Sheet
- Financial overview with total earned and unpaid amounts
- Detailed breakdown of all work entries
- CSV export functionality for record keeping

#### ℹ️ About
- App information and version details
- Feature list and description

### Navigation Menu
Access all features through the hamburger menu:
- 🏠 **Home** - Return to dashboard
- 📋 **History** - View work history
- 💰 **Balance Sheet** - Financial summary
- 📊 **Charts** - Analytics (coming soon)
- 🌙 **Theme Toggle** - Switch between light/dark themes
- 🗑️ **Clear History** - Reset all data
- ℹ️ **About** - App information

## Data Management

### Local Storage
- All data is stored locally using Room database
- No internet connection required
- Data persists across app updates

### Export Options
- **CSV Export**: Export balance sheet as CSV file to Downloads folder
- **Manual Backup**: Copy database file for manual backup

### Data Privacy
- No personal data is transmitted to external servers
- All information stays on your device
- No analytics or tracking implemented

## Development

### Architecture Overview
The app follows MVVM architecture pattern:

- **Model**: Room database entities and DAOs
- **View**: Activities and XML layouts
- **ViewModel**: Business logic and data management

### Key Components

#### Database Schema
```kotlin
@Entity(tableName = "work_entries")
data class WorkEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Date,
    val amount: Double = 25.0,
    val isPaid: Boolean = false,
    val paymentDate: Date? = null,
    val notes: String? = null
)
```

#### Payment Logic
- Every 4 work entries = ₹100 payment batch
- Automatic calculation of payment due dates
- Notification system for payment reminders

## Contributing

We welcome contributions! Please follow these guidelines:

1. **Fork the repository**
2. **Create a feature branch** (`git checkout -b feature/amazing-feature`)
3. **Commit your changes** (`git commit -m 'Add amazing feature'`)
4. **Push to the branch** (`git push origin feature/amazing-feature`)
5. **Open a Pull Request**

### Code Style
- Follow Kotlin coding conventions
- Use meaningful variable and function names
- Add comments for complex logic
- Maintain consistent indentation

## Version History

### v1.0.0 (Current)
- ✅ Daily work tracking with one-click marking
- ✅ Automatic earnings calculation (₹25/day)
- ✅ Payment notifications every 4 days
- ✅ Comprehensive history with filters
- ✅ Balance sheet with CSV export
- ✅ Dark/Light theme support
- ✅ Daily strike counter
- ✅ Material Design 3 UI

### Future Enhancements
- 📊 Advanced charts and analytics
- 🔄 Cloud backup and sync
- 📱 Widget support
- 🗓️ Calendar integration
- 💼 Multiple job tracking
- 📧 Email export options

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

If you encounter any issues or have questions:

1. **Check the Issues** - Look for existing solutions
2. **Create an Issue** - Report bugs or request features
3. **Contact** - Reach out for additional support

## Acknowledgments

- **Material Design** - Google's design system
- **Android Jetpack** - Modern Android development components
- **Room Database** - Local data persistence
- **MPAndroidChart** - Chart library for analytics

---

**Made with ❤️ for drivers who want to track their earnings efficiently**