package com.rservice.tracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.rservice.tracker.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupContent()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = getString(R.string.about_title)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun setupContent() {
        binding.tvAppVersion.text = getString(R.string.app_version)
        binding.tvAppDescription.text = getString(R.string.app_description)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}