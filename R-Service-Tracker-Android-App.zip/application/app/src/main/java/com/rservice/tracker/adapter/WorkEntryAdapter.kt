package com.rservice.tracker.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.rservice.tracker.R
import com.rservice.tracker.data.WorkEntry
import com.rservice.tracker.databinding.ItemWorkEntryBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class WorkEntryAdapter : ListAdapter<WorkEntry, WorkEntryAdapter.WorkEntryViewHolder>(WorkEntryDiffCallback()) {

    private val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
    private val dayFormat = SimpleDateFormat("EEEE", Locale.getDefault())
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkEntryViewHolder {
        val binding = ItemWorkEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return WorkEntryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WorkEntryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class WorkEntryViewHolder(private val binding: ItemWorkEntryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(workEntry: WorkEntry) {
            binding.tvDate.text = dateFormat.format(workEntry.date)
            binding.tvDayName.text = dayFormat.format(workEntry.date)
            
            val formattedAmount = currencyFormat.format(workEntry.amount)
            binding.tvAmount.text = formattedAmount.replace("INR", "₹")

            // Update status chip
            if (workEntry.isPaid) {
                binding.chipStatus.text = binding.root.context.getString(R.string.paid)
                binding.chipStatus.setChipBackgroundColorResource(R.color.success_color)
                binding.chipStatus.setTextColor(ContextCompat.getColor(binding.root.context, android.R.color.white))
            } else {
                binding.chipStatus.text = binding.root.context.getString(R.string.unpaid)
                binding.chipStatus.setChipBackgroundColorResource(R.color.warning_color)
                binding.chipStatus.setTextColor(ContextCompat.getColor(binding.root.context, android.R.color.white))
            }
        }
    }

    class WorkEntryDiffCallback : DiffUtil.ItemCallback<WorkEntry>() {
        override fun areItemsTheSame(oldItem: WorkEntry, newItem: WorkEntry): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: WorkEntry, newItem: WorkEntry): Boolean {
            return oldItem == newItem
        }
    }
}