package com.rservice.tracker.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rservice.tracker.data.PaymentBatch
import com.rservice.tracker.data.PaymentBatchDao
import com.rservice.tracker.data.WorkEntry
import com.rservice.tracker.data.WorkEntryDao
import kotlinx.coroutines.launch
import java.util.Date

class MainViewModel(
    private val workEntryDao: WorkEntryDao,
    private val paymentBatchDao: PaymentBatchDao
) : ViewModel() {

    val allWorkEntries: LiveData<List<WorkEntry>> = workEntryDao.getAllWorkEntries()
    val totalUnpaidAmount: LiveData<Double?> = workEntryDao.getTotalUnpaidAmount()
    val totalEarnedAmount: LiveData<Double?> = workEntryDao.getTotalEarnedAmount()
    val allPaymentBatches: LiveData<List<PaymentBatch>> = paymentBatchDao.getAllPaymentBatches()

    suspend fun insertWorkEntry(workEntry: WorkEntry): Long {
        return workEntryDao.insertWorkEntry(workEntry)
    }

    suspend fun getWorkEntryByDate(date: Date): WorkEntry? {
        return workEntryDao.getWorkEntryByDate(date)
    }

    suspend fun getUnpaidWorkDaysCount(): Int {
        return workEntryDao.getUnpaidWorkDaysCount()
    }

    suspend fun getWorkEntriesBetweenDates(startDate: Date, endDate: Date): List<WorkEntry> {
        return workEntryDao.getWorkEntriesBetweenDates(startDate, endDate)
    }

    suspend fun markEntriesAsPaid(ids: List<Long>, paymentDate: Date) {
        workEntryDao.markEntriesAsPaid(ids, paymentDate)
    }

    suspend fun insertPaymentBatch(paymentBatch: PaymentBatch): Long {
        return paymentBatchDao.insertPaymentBatch(paymentBatch)
    }

    fun clearAllData() {
        viewModelScope.launch {
            workEntryDao.deleteAllWorkEntries()
            paymentBatchDao.deleteAllPaymentBatches()
        }
    }

    suspend fun getUnpaidWorkEntries(): List<WorkEntry> {
        return workEntryDao.getUnpaidWorkEntries()
    }
}