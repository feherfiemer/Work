package com.rservice.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "work_entries")
data class WorkEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Date,
    val amount: Double = 25.0, // Default 25 rupees per day
    val isPaid: Boolean = false,
    val paymentDate: Date? = null,
    val notes: String? = null
)