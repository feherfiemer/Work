package com.rservice.tracker

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import com.rservice.tracker.data.AppDatabase
import com.rservice.tracker.data.WorkEntry
import com.rservice.tracker.databinding.ActivityMainBinding
import com.rservice.tracker.viewmodel.MainViewModel
import com.rservice.tracker.viewmodel.MainViewModelFactory
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var viewModel: MainViewModel
    private lateinit var sharedPreferences: SharedPreferences
    private val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Apply theme
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        applyTheme()
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupNavigationDrawer()
        setupViewModel()
        setupObservers()
        setupClickListeners()
        updateUI()
    }

    private fun applyTheme() {
        val theme = sharedPreferences.getString("theme", "system")
        when (theme) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)
    }

    private fun setupNavigationDrawer() {
        drawerLayout = binding.drawerLayout
        val navigationView = binding.navView
        navigationView.setNavigationItemSelectedListener(this)

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, binding.toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Set home as selected by default
        navigationView.setCheckedItem(R.id.nav_home)
    }

    private fun setupViewModel() {
        val database = AppDatabase.getDatabase(this)
        val factory = MainViewModelFactory(database.workEntryDao(), database.paymentBatchDao())
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
    }

    private fun setupObservers() {
        // Observe total unpaid amount
        viewModel.totalUnpaidAmount.observe(this) { amount ->
            val formattedAmount = currencyFormat.format(amount ?: 0.0)
            binding.tvUnpaidAmount.text = formattedAmount.replace("INR", "₹")
        }

        // Observe total earned amount
        viewModel.totalEarnedAmount.observe(this) { amount ->
            val formattedAmount = currencyFormat.format(amount ?: 0.0)
            binding.tvTotalEarned.text = formattedAmount.replace("INR", "₹")
        }

        // Observe work entries for strike calculation
        viewModel.allWorkEntries.observe(this) { entries ->
            updateStrikeCounter(entries)
            updatePaymentStatus()
        }
    }

    private fun setupClickListeners() {
        binding.btnMarkWorkDone.setOnClickListener {
            markWorkDone()
        }

        binding.btnViewHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnViewBalance.setOnClickListener {
            startActivity(Intent(this, BalanceSheetActivity::class.java))
        }
    }

    private fun updateUI() {
        // Set current date
        binding.tvCurrentDate.text = dateFormat.format(Date())
        
        // Check if work is already marked for today
        lifecycleScope.launch {
            val today = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.time

            val todayEntry = viewModel.getWorkEntryByDate(today)
            if (todayEntry != null) {
                binding.btnMarkWorkDone.isEnabled = false
                binding.btnMarkWorkDone.text = getString(R.string.already_marked_today)
                binding.tvWorkStatus.text = getString(R.string.work_done_today)
                binding.tvWorkStatus.visibility = android.view.View.VISIBLE
            }
        }
    }

    private fun markWorkDone() {
        lifecycleScope.launch {
            try {
                val today = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.time

                // Check if already marked for today
                val existingEntry = viewModel.getWorkEntryByDate(today)
                if (existingEntry != null) {
                    Toast.makeText(this@MainActivity, R.string.already_marked_today, Toast.LENGTH_SHORT).show()
                    return@launch
                }

                // Create new work entry
                val workEntry = WorkEntry(
                    date = today,
                    amount = 25.0
                )

                viewModel.insertWorkEntry(workEntry)

                // Update UI
                binding.btnMarkWorkDone.isEnabled = false
                binding.btnMarkWorkDone.text = getString(R.string.already_marked_today)
                binding.tvWorkStatus.text = getString(R.string.work_done_today)
                binding.tvWorkStatus.visibility = android.view.View.VISIBLE

                // Show success message
                Snackbar.make(binding.root, R.string.work_done_today, Snackbar.LENGTH_LONG).show()

                // Check if payment is due
                checkPaymentDue()

            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error marking work done: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateStrikeCounter(entries: List<WorkEntry>) {
        val sortedEntries = entries.sortedByDescending { it.date }
        var consecutiveDays = 0
        val calendar = Calendar.getInstance()
        
        // Start from today and count backwards
        for (entry in sortedEntries) {
            val entryCalendar = Calendar.getInstance().apply { time = entry.date }
            val expectedDate = Calendar.getInstance().apply {
                time = calendar.time
                add(Calendar.DAY_OF_MONTH, -consecutiveDays)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            
            if (isSameDay(entryCalendar, expectedDate)) {
                consecutiveDays++
            } else {
                break
            }
        }

        binding.tvStrikeCount.text = consecutiveDays.toString()
        binding.tvStrikeDescription.text = getString(R.string.consecutive_days, consecutiveDays)
    }

    private fun updatePaymentStatus() {
        lifecycleScope.launch {
            val unpaidCount = viewModel.getUnpaidWorkDaysCount()
            val daysUntilPayment = 4 - (unpaidCount % 4)
            
            if (unpaidCount >= 4) {
                binding.tvPaymentStatus.text = getString(R.string.payment_ready)
                binding.tvPaymentStatus.setTextColor(getColor(R.color.success_color))
            } else {
                binding.tvPaymentStatus.text = "$daysUntilPayment ${getString(R.string.days_until_payment)}"
                binding.tvPaymentStatus.setTextColor(getColor(R.color.info_color))
            }
        }
    }

    private suspend fun checkPaymentDue() {
        val unpaidCount = viewModel.getUnpaidWorkDaysCount()
        if (unpaidCount >= 4 && unpaidCount % 4 == 0) {
            // Payment is due - show notification
            val amount = unpaidCount / 4 * 100 // 4 days = 100 rupees
            showPaymentNotification(amount)
        }
    }

    private fun showPaymentNotification(amount: Int) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.payment_notification_title))
            .setMessage(getString(R.string.payment_notification_text, amount))
            .setPositiveButton(getString(R.string.ok)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun isSameDay(cal1: Calendar, cal2: Calendar): Boolean {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> {
                // Already on home, do nothing
            }
            R.id.nav_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
            }
            R.id.nav_balance_sheet -> {
                startActivity(Intent(this, BalanceSheetActivity::class.java))
            }
            R.id.nav_charts -> {
                startActivity(Intent(this, ChartsActivity::class.java))
            }
            R.id.nav_theme_toggle -> {
                showThemeDialog()
            }
            R.id.nav_clear_history -> {
                showClearHistoryDialog()
            }
            R.id.nav_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
            }
        }

        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun showThemeDialog() {
        val themes = arrayOf(
            getString(R.string.light_theme),
            getString(R.string.dark_theme),
            getString(R.string.system_theme)
        )
        
        val currentTheme = sharedPreferences.getString("theme", "system")
        val checkedItem = when (currentTheme) {
            "light" -> 0
            "dark" -> 1
            else -> 2
        }

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.menu_theme_toggle))
            .setSingleChoiceItems(themes, checkedItem) { dialog, which ->
                val selectedTheme = when (which) {
                    0 -> "light"
                    1 -> "dark"
                    else -> "system"
                }
                
                sharedPreferences.edit()
                    .putString("theme", selectedTheme)
                    .apply()
                
                applyTheme()
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showClearHistoryDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_clear_history))
            .setMessage(getString(R.string.confirm_clear_history_message))
            .setPositiveButton(getString(R.string.clear)) { _, _ ->
                clearHistory()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun clearHistory() {
        lifecycleScope.launch {
            try {
                viewModel.clearAllData()
                Toast.makeText(this@MainActivity, "History cleared successfully", Toast.LENGTH_SHORT).show()
                
                // Reset UI
                binding.btnMarkWorkDone.isEnabled = true
                binding.btnMarkWorkDone.text = getString(R.string.mark_work_done)
                binding.tvWorkStatus.visibility = android.view.View.GONE
                
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error clearing history: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}