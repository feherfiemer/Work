package com.rservice.tracker.data

import androidx.lifecycle.LiveData
import androidx.room.*
import java.util.Date

@Dao
interface WorkEntryDao {
    @Query("SELECT * FROM work_entries ORDER BY date DESC")
    fun getAllWorkEntries(): LiveData<List<WorkEntry>>

    @Query("SELECT * FROM work_entries WHERE date = :date LIMIT 1")
    suspend fun getWorkEntryByDate(date: Date): WorkEntry?

    @Query("SELECT COUNT(*) FROM work_entries WHERE date = :date")
    suspend fun getWorkEntryCountByDate(date: Date): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkEntry(workEntry: WorkEntry): Long

    @Update
    suspend fun updateWorkEntry(workEntry: WorkEntry)

    @Delete
    suspend fun deleteWorkEntry(workEntry: WorkEntry)

    @Query("DELETE FROM work_entries")
    suspend fun deleteAllWorkEntries()

    @Query("SELECT * FROM work_entries WHERE isPaid = 0 ORDER BY date ASC")
    suspend fun getUnpaidWorkEntries(): List<WorkEntry>

    @Query("SELECT SUM(amount) FROM work_entries WHERE isPaid = 0")
    fun getTotalUnpaidAmount(): LiveData<Double?>

    @Query("SELECT SUM(amount) FROM work_entries")
    fun getTotalEarnedAmount(): LiveData<Double?>

    @Query("SELECT COUNT(*) FROM work_entries WHERE isPaid = 0")
    suspend fun getUnpaidWorkDaysCount(): Int

    @Query("SELECT * FROM work_entries WHERE date BETWEEN :startDate AND :endDate ORDER BY date ASC")
    suspend fun getWorkEntriesBetweenDates(startDate: Date, endDate: Date): List<WorkEntry>

    @Query("UPDATE work_entries SET isPaid = 1, paymentDate = :paymentDate WHERE id IN (:ids)")
    suspend fun markEntriesAsPaid(ids: List<Long>, paymentDate: Date)
}

@Dao
interface PaymentBatchDao {
    @Query("SELECT * FROM payment_batches ORDER BY paymentDate DESC")
    fun getAllPaymentBatches(): LiveData<List<PaymentBatch>>

    @Insert
    suspend fun insertPaymentBatch(paymentBatch: PaymentBatch): Long

    @Update
    suspend fun updatePaymentBatch(paymentBatch: PaymentBatch)

    @Delete
    suspend fun deletePaymentBatch(paymentBatch: PaymentBatch)

    @Query("DELETE FROM payment_batches")
    suspend fun deleteAllPaymentBatches()

    @Query("SELECT SUM(totalAmount) FROM payment_batches WHERE isReceived = 1")
    fun getTotalReceivedAmount(): LiveData<Double?>
}