package com.rservice.tracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.rservice.tracker.databinding.ActivityChartsBinding

class ChartsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChartsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChartsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        // Chart implementation would go here
        // For now, showing a placeholder message
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = getString(R.string.charts_title)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}