package com.rservice.tracker

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.rservice.tracker.adapter.WorkEntryAdapter
import com.rservice.tracker.data.AppDatabase
import com.rservice.tracker.data.WorkEntry
import com.rservice.tracker.databinding.ActivityHistoryBinding
import com.rservice.tracker.viewmodel.MainViewModel
import com.rservice.tracker.viewmodel.MainViewModelFactory
import kotlinx.coroutines.launch
import java.util.*

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: WorkEntryAdapter
    private var allEntries: List<WorkEntry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViewModel()
        setupRecyclerView()
        setupTabs()
        setupObservers()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = getString(R.string.history_title)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun setupViewModel() {
        val database = AppDatabase.getDatabase(this)
        val factory = MainViewModelFactory(database.workEntryDao(), database.paymentBatchDao())
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
    }

    private fun setupRecyclerView() {
        adapter = WorkEntryAdapter()
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = adapter
    }

    private fun setupTabs() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("All"))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(getString(R.string.this_week)))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(getString(R.string.last_week)))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(getString(R.string.this_month)))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(getString(R.string.last_month)))

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                filterEntries(tab?.position ?: 0)
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupObservers() {
        viewModel.allWorkEntries.observe(this) { entries ->
            allEntries = entries
            updateSummary(entries)
            filterEntries(binding.tabLayout.selectedTabPosition)
        }
    }

    private fun updateSummary(entries: List<WorkEntry>) {
        val totalDays = entries.size
        val paidDays = entries.count { it.isPaid }
        val unpaidDays = totalDays - paidDays

        binding.tvTotalDays.text = totalDays.toString()
        binding.tvPaidDays.text = paidDays.toString()
        binding.tvUnpaidDays.text = unpaidDays.toString()
    }

    private fun filterEntries(tabPosition: Int) {
        val calendar = Calendar.getInstance()
        val filteredEntries = when (tabPosition) {
            0 -> allEntries // All
            1 -> getThisWeekEntries(calendar) // This Week
            2 -> getLastWeekEntries(calendar) // Last Week
            3 -> getThisMonthEntries(calendar) // This Month
            4 -> getLastMonthEntries(calendar) // Last Month
            else -> allEntries
        }

        adapter.submitList(filteredEntries)
        
        if (filteredEntries.isEmpty()) {
            binding.layoutEmptyState.visibility = View.VISIBLE
            binding.rvHistory.visibility = View.GONE
        } else {
            binding.layoutEmptyState.visibility = View.GONE
            binding.rvHistory.visibility = View.VISIBLE
        }
    }

    private fun getThisWeekEntries(calendar: Calendar): List<WorkEntry> {
        val startOfWeek = calendar.clone() as Calendar
        startOfWeek.set(Calendar.DAY_OF_WEEK, startOfWeek.firstDayOfWeek)
        startOfWeek.set(Calendar.HOUR_OF_DAY, 0)
        startOfWeek.set(Calendar.MINUTE, 0)
        startOfWeek.set(Calendar.SECOND, 0)
        startOfWeek.set(Calendar.MILLISECOND, 0)

        val endOfWeek = calendar.clone() as Calendar
        endOfWeek.set(Calendar.DAY_OF_WEEK, startOfWeek.firstDayOfWeek + 6)
        endOfWeek.set(Calendar.HOUR_OF_DAY, 23)
        endOfWeek.set(Calendar.MINUTE, 59)
        endOfWeek.set(Calendar.SECOND, 59)
        endOfWeek.set(Calendar.MILLISECOND, 999)

        return allEntries.filter { entry ->
            entry.date.time >= startOfWeek.timeInMillis && entry.date.time <= endOfWeek.timeInMillis
        }
    }

    private fun getLastWeekEntries(calendar: Calendar): List<WorkEntry> {
        val startOfLastWeek = calendar.clone() as Calendar
        startOfLastWeek.add(Calendar.WEEK_OF_YEAR, -1)
        startOfLastWeek.set(Calendar.DAY_OF_WEEK, startOfLastWeek.firstDayOfWeek)
        startOfLastWeek.set(Calendar.HOUR_OF_DAY, 0)
        startOfLastWeek.set(Calendar.MINUTE, 0)
        startOfLastWeek.set(Calendar.SECOND, 0)
        startOfLastWeek.set(Calendar.MILLISECOND, 0)

        val endOfLastWeek = calendar.clone() as Calendar
        endOfLastWeek.add(Calendar.WEEK_OF_YEAR, -1)
        endOfLastWeek.set(Calendar.DAY_OF_WEEK, startOfLastWeek.firstDayOfWeek + 6)
        endOfLastWeek.set(Calendar.HOUR_OF_DAY, 23)
        endOfLastWeek.set(Calendar.MINUTE, 59)
        endOfLastWeek.set(Calendar.SECOND, 59)
        endOfLastWeek.set(Calendar.MILLISECOND, 999)

        return allEntries.filter { entry ->
            entry.date.time >= startOfLastWeek.timeInMillis && entry.date.time <= endOfLastWeek.timeInMillis
        }
    }

    private fun getThisMonthEntries(calendar: Calendar): List<WorkEntry> {
        val startOfMonth = calendar.clone() as Calendar
        startOfMonth.set(Calendar.DAY_OF_MONTH, 1)
        startOfMonth.set(Calendar.HOUR_OF_DAY, 0)
        startOfMonth.set(Calendar.MINUTE, 0)
        startOfMonth.set(Calendar.SECOND, 0)
        startOfMonth.set(Calendar.MILLISECOND, 0)

        val endOfMonth = calendar.clone() as Calendar
        endOfMonth.set(Calendar.DAY_OF_MONTH, endOfMonth.getActualMaximum(Calendar.DAY_OF_MONTH))
        endOfMonth.set(Calendar.HOUR_OF_DAY, 23)
        endOfMonth.set(Calendar.MINUTE, 59)
        endOfMonth.set(Calendar.SECOND, 59)
        endOfMonth.set(Calendar.MILLISECOND, 999)

        return allEntries.filter { entry ->
            entry.date.time >= startOfMonth.timeInMillis && entry.date.time <= endOfMonth.timeInMillis
        }
    }

    private fun getLastMonthEntries(calendar: Calendar): List<WorkEntry> {
        val startOfLastMonth = calendar.clone() as Calendar
        startOfLastMonth.add(Calendar.MONTH, -1)
        startOfLastMonth.set(Calendar.DAY_OF_MONTH, 1)
        startOfLastMonth.set(Calendar.HOUR_OF_DAY, 0)
        startOfLastMonth.set(Calendar.MINUTE, 0)
        startOfLastMonth.set(Calendar.SECOND, 0)
        startOfLastMonth.set(Calendar.MILLISECOND, 0)

        val endOfLastMonth = calendar.clone() as Calendar
        endOfLastMonth.add(Calendar.MONTH, -1)
        endOfLastMonth.set(Calendar.DAY_OF_MONTH, endOfLastMonth.getActualMaximum(Calendar.DAY_OF_MONTH))
        endOfLastMonth.set(Calendar.HOUR_OF_DAY, 23)
        endOfLastMonth.set(Calendar.MINUTE, 59)
        endOfLastMonth.set(Calendar.SECOND, 59)
        endOfLastMonth.set(Calendar.MILLISECOND, 999)

        return allEntries.filter { entry ->
            entry.date.time >= startOfLastMonth.timeInMillis && entry.date.time <= endOfLastMonth.timeInMillis
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}