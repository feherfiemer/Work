package com.rservice.tracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.rservice.tracker.data.PaymentBatchDao
import com.rservice.tracker.data.WorkEntryDao

class MainViewModelFactory(
    private val workEntryDao: WorkEntryDao,
    private val paymentBatchDao: PaymentBatchDao
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(workEntryDao, paymentBatchDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}