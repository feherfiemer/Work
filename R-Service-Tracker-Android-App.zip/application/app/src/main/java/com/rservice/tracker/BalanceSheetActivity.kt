package com.rservice.tracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.rservice.tracker.adapter.WorkEntryAdapter
import com.rservice.tracker.data.AppDatabase
import com.rservice.tracker.databinding.ActivityBalanceSheetBinding
import com.rservice.tracker.viewmodel.MainViewModel
import com.rservice.tracker.viewmodel.MainViewModelFactory
import java.io.File
import java.io.FileWriter
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class BalanceSheetActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBalanceSheetBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: WorkEntryAdapter
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    private val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())

    companion object {
        private const val STORAGE_PERMISSION_CODE = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBalanceSheetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViewModel()
        setupRecyclerView()
        setupObservers()
        setupClickListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = getString(R.string.balance_sheet_title)
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun setupViewModel() {
        val database = AppDatabase.getDatabase(this)
        val factory = MainViewModelFactory(database.workEntryDao(), database.paymentBatchDao())
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
    }

    private fun setupRecyclerView() {
        adapter = WorkEntryAdapter()
        binding.rvBalanceDetails.layoutManager = LinearLayoutManager(this)
        binding.rvBalanceDetails.adapter = adapter
    }

    private fun setupObservers() {
        viewModel.totalEarnedAmount.observe(this) { amount ->
            val formattedAmount = currencyFormat.format(amount ?: 0.0)
            binding.tvTotalEarned.text = formattedAmount.replace("INR", "₹")
        }

        viewModel.totalUnpaidAmount.observe(this) { amount ->
            val formattedAmount = currencyFormat.format(amount ?: 0.0)
            binding.tvTotalUnpaid.text = formattedAmount.replace("INR", "₹")
        }

        viewModel.allWorkEntries.observe(this) { entries ->
            adapter.submitList(entries)
        }
    }

    private fun setupClickListeners() {
        binding.btnExportPdf.setOnClickListener {
            if (checkStoragePermission()) {
                exportToPdf()
            } else {
                requestStoragePermission()
            }
        }
    }

    private fun checkStoragePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
            STORAGE_PERMISSION_CODE
        )
    }

    private fun exportToPdf() {
        try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val fileName = "RService_Balance_Sheet_${System.currentTimeMillis()}.csv"
            val file = File(downloadsDir, fileName)

            FileWriter(file).use { writer ->
                // Write CSV header
                writer.append("Date,Amount,Status\n")
                
                // Write data
                viewModel.allWorkEntries.value?.forEach { entry ->
                    writer.append("${dateFormat.format(entry.date)},")
                    writer.append("${entry.amount},")
                    writer.append("${if (entry.isPaid) "Paid" else "Unpaid"}\n")
                }
            }

            Toast.makeText(this, "Balance sheet exported to Downloads/$fileName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                exportToPdf()
            } else {
                Toast.makeText(this, "Storage permission required to export PDF", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}