package com.rservice.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "payment_batches")
data class PaymentBatch(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val startDate: Date,
    val endDate: Date,
    val totalAmount: Double,
    val workDaysCount: Int,
    val paymentDate: Date,
    val isReceived: Boolean = false
)